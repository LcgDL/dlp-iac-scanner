# Serverless DLP Analysis of IaC Files on GCP

Dieses Projekt demonstriert eine serverlose Lösung zur Erkennung sensibler Daten in Infrastructure-as-Code-Dateien (Terraform) mithilfe von Google Cloud DLP, Cloud Functions, Pub/Sub, BigQuery und Cloud Build.

## Architektur
![Architecture Diagram](architecture/architecture_diagram.png)

## Überblick
- **Input:** Terraform-Dateien (IaC)
- **Verarbeitung:** Cloud Function mit Python (google-cloud-dlp, re)
- **Output:** Ergebnisse in BigQuery, Benachrichtigung über Pub/Sub
- **Automatisierung:** Terraform & Cloud Build

🎯 Zeigt Kompetenz in Cloud Security, Automatisierung, Python und IaC.
