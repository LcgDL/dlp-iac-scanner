def test_dlp_function_mock():
    assert True
