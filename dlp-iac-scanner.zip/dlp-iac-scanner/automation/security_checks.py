print("Running Terraform security checks...")
